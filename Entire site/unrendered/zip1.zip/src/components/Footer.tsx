export default function Footer() {
  return (
    <footer className="pt-2 pb-5 bg-background w-full mt-2 px-5">
      <div className="max-w-7xl mx-auto">
        <div className="w-full h-[400px] md:h-[500px] rounded-[20px] flex flex-col justify-between relative border bg-[#f3f3f4] border-outline p-10">
          <div className="max-w-md">
            <h3 className="text-3xl md:text-4xl font-light text-primary mb-4 font-serif">Embrace the minimal.</h3>
            <p className="text-secondary leading-relaxed font-light">
              Focus on what matters. Our platform strips away distractions, allowing you to master the core principles of design in a focused environment.
            </p>
          </div>
          <div className="flex flex-col md:flex-row justify-between items-end w-full gap-8">
            <div className="text-7xl md:text-[8rem] font-bold tracking-tighter text-primary/80 leading-none">Learn</div>
            <div className="flex flex-col items-end gap-6 mb-2">
              <div className="text-xs text-secondary font-light text-right">
                © 2024 Learning Platform. Built with intention.
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
