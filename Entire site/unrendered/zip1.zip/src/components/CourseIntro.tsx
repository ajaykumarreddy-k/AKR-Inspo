export default function CourseIntro() {
  return (
    <section className="pt-8 px-5 pb-20">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="lg:w-2/5 flex items-start pt-3">
            <span className="text-xs font-semibold text-secondary tracking-[0.2em] uppercase whitespace-nowrap">
              The Course
            </span>
          </div>
          <div className="lg:w-3/5">
            <p className="text-primary leading-tight font-light tracking-tight text-3xl md:text-4xl font-serif">
              This comprehensive course strips away the unnecessary, focusing on core principles of spatial relationship, typography, and purposeful white space. 
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
