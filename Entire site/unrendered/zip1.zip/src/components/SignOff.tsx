import { motion } from 'motion/react';

export default function SignOff() {
  return (
    <section className="bg-background pb-0 px-5">
      <div className="max-w-7xl mx-auto">
        <div className="relative w-full h-[400px] md:h-[500px] rounded-[20px] overflow-hidden flex items-center justify-center">
          <img 
            alt="Serene mountain sunrise" 
            className="absolute inset-0 w-full h-full object-cover" 
            src="https://images.unsplash.com/photo-1434394354979-a235cd36269d?q=80&w=2051&auto=format&fit=crop" 
          />
          <div className="relative z-10 flex flex-col items-center text-center px-8 py-12 mx-6">
            <span className="text-xs font-semibold text-primary tracking-[0.2em] uppercase mb-6">Core Capabilities</span>
            <h2 className="text-4xl md:text-5xl font-light text-primary leading-tight max-w-2xl font-serif">
              Ready to elevate your digital experience?
            </h2>
            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-primary text-white text-xs font-medium px-6 py-2.5 rounded-full hover:bg-primary/90 transition-all duration-300 tracking-wide mt-8 uppercase"
            >
              Start Learning Now
            </motion.button>
          </div>
        </div>
      </div>
    </section>
  );
}
