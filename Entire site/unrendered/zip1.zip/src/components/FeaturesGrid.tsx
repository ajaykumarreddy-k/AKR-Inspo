import { Library, Share2, History, Users } from 'lucide-react';

const features = [
  {
    icon: Library,
    title: "Structured Libraries",
    desc: "Organize your materials by discipline, methodology, or specific research question with precise control."
  },
  {
    icon: Share2,
    title: "Knowledge Graph",
    desc: "Visualize connections between concepts and authors across your entire scholarly library."
  },
  {
    icon: History,
    title: "Citation Tracking",
    desc: "Automatically generate and verify citations in any major academic format seamlessly."
  },
  {
    icon: Users,
    title: "Peer Collaboration",
    desc: "Share annotations and debate interpretations in a shared, focused academic environment."
  }
];

export default function FeaturesGrid() {
  return (
    <section className="pb-20 pt-8 px-5">
      <div className="max-w-7xl mx-auto">
        <div className="mb-16">
          <span className="text-xs font-semibold text-secondary tracking-[0.2em] uppercase">Core Capabilities</span>
          <h2 className="text-4xl md:text-5xl font-light text-primary mt-4 leading-tight font-serif">
            Advanced tools for<br />modern scholarship
          </h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 pt-10">
          {features.map((feat, idx) => (
            <div key={idx} className="flex flex-col relative group">
              <div className="w-full border-t border-outline"></div>
              <feat.icon className="text-primary w-6 h-6 mt-6 transition-transform group-hover:scale-110" strokeWidth={1.5} />
              <h3 className="text-xl font-medium text-primary mb-3 pt-20 tracking-tight font-serif">
                {feat.title}
              </h3>
              <p className="text-base text-secondary font-light leading-relaxed">
                {feat.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
