import { motion } from 'motion/react';

const logos = [
  { name: 'VOGUE', style: 'font-bold tracking-tight' },
  { name: 'MONOCLE', style: 'tracking-widest font-light' },
  { name: 'Kinfolk', style: 'italic font-medium' },
  { name: 'CEREAL', style: 'uppercase font-semibold' },
  { name: 'MUSEUM', style: 'tracking-wide' },
];

export default function LogoTicker() {
  return (
    <section className="w-full overflow-hidden mb-16 bg-surface pt-20 pb-20 border-y border-outline">
      <div className="flex w-max opacity-60">
        <motion.div 
          animate={{ x: ["0%", "-50%"] }}
          transition={{ repeat: Infinity, ease: "linear", duration: 30 }}
          className="flex items-center"
        >
          {[...logos, ...logos, ...logos, ...logos].map((logo, i) => (
            <div key={i} className={`text-xl text-primary mx-16 ${logo.style}`}>
              {logo.name}
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
