import { motion } from 'motion/react';

export default function Hero() {
  return (
    <section className="relative w-full overflow-hidden flex flex-col items-center justify-center pt-5 pb-15 px-5">
      <div className="relative w-full max-w-7xl mx-auto rounded-[20px] overflow-hidden flex items-center justify-center min-h-[600px] pt-32 pb-12">
        <div className="absolute top-10 left-0 right-0 flex justify-center z-20">
          <div className="text-xl font-bold tracking-tight text-primary">Horizon</div>
        </div>
        <img 
          alt="Mountain sunrise" 
          className="absolute inset-0 w-full h-full object-cover" 
          src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?q=80&w=2070&auto=format&fit=crop" 
        />
        <div className="relative z-10 w-full px-8 text-center py-12 mx-8 rounded-[20px] max-w-4xl">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="text-4xl md:text-6xl font-light text-primary leading-tight tracking-tight mb-8 font-serif"
          >
            Master the Art of Minimalist<br />Design in the Modern Era
          </motion.h1>
          <motion.button 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
            className="bg-primary text-white text-xs font-medium px-6 py-2.5 rounded-full hover:bg-primary/90 transition-all duration-300 tracking-wide uppercase"
          >
            Get Started Today
          </motion.button>
        </div>
      </div>
    </section>
  );
}
