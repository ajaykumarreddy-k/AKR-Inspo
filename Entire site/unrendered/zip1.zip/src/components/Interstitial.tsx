import { motion } from 'motion/react';

export default function Interstitial() {
  return (
    <section className="pt-12 pb-12 px-5">
      <div className="max-w-7xl mx-auto">
        <div className="relative w-full h-[400px] md:h-[500px] rounded-[20px] overflow-hidden flex items-center justify-center">
          <img 
            alt="Serene mountain landscape" 
            className="absolute inset-0 w-full h-full object-cover" 
            src="https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=2070&auto=format&fit=crop" 
          />
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative z-10 w-full px-8 text-center flex flex-col items-center justify-center h-full max-w-3xl mx-auto rounded-[20px]"
          >
            <h2 className="text-3xl md:text-5xl font-light text-primary leading-tight tracking-tight max-w-2xl mx-auto font-serif">
              Embrace the whitespace and find clarity in simplicity.
            </h2>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
