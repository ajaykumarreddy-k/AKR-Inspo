import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Lightbulb } from 'lucide-react';

const items = [
  {
    title: "Choose an objective",
    desc: "Select a focus area like theoretical foundations, empirical analysis, or historical context review."
  },
  {
    title: "Generate insights",
    desc: "Our system correlates data across multiple texts to provide you with unique perspectives and hidden linkages."
  },
  {
    title: "Validate at scale",
    desc: "Test your hypotheses against extensive academic databases to confirm the validity of your conclusions."
  }
];

export default function SmartInsights({ reversed = false }: { reversed?: boolean }) {
  const [activeIndex, setActiveIndex] = useState<number>(0);

  return (
    <section className="pb-12 pt-8 px-5">
      <div className="max-w-7xl mx-auto">
        {!reversed && (
          <div className="mb-12">
            <span className="text-xs font-semibold text-secondary tracking-[0.2em] uppercase">Core Capabilities</span>
            <h2 className="font-light text-primary mt-4 leading-tight text-4xl md:text-5xl font-serif">
              Everything you need to<br />master your workflow
            </h2>
          </div>
        )}
        
        <div className={`border-outline overflow-hidden flex flex-col ${reversed ? 'lg:flex-row-reverse' : 'lg:flex-row'} w-full min-h-[700px] gap-12`}>
          {/* Left Side: List */}
          <div className="w-full lg:w-2/5 flex flex-col justify-between py-5">
            <div className="max-w-md w-full h-full flex flex-col">
              <div>
                <div className="flex items-center gap-3 mb-6">
                  <Lightbulb className="text-primary w-8 h-8" strokeWidth={1.5} />
                  <h2 className="font-light text-primary tracking-tight text-4xl font-serif">Smart Insights</h2>
                </div>
                <p className="text-secondary text-sm mb-10 leading-relaxed font-light">
                  Your environment will surface patterns and uncover root causes, then offer pathways on how to structure your studies to improve retention, based on the academic objectives you choose.
                </p>
              </div>

              <div className="space-y-2 mt-auto">
                {items.map((item, idx) => (
                  <div 
                    key={idx} 
                    className="group cursor-pointer"
                    onMouseEnter={() => setActiveIndex(idx)}
                    onClick={() => setActiveIndex(idx)}
                  >
                    <div className="border-t border-outline pt-6 pb-4 relative overflow-hidden">
                      <div className={`absolute top-0 left-0 h-[2px] bg-primary transition-all duration-500 ${activeIndex === idx ? 'w-full' : 'w-0'}`}></div>
                      <h3 className={`text-lg font-medium mb-2 transition-colors ${activeIndex === idx ? 'text-primary' : 'text-secondary group-hover:text-primary'}`}>
                        {item.title}
                      </h3>
                      <AnimatePresence>
                        {activeIndex === idx && (
                          <motion.div 
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="overflow-hidden"
                          >
                            <p className="text-sm text-secondary leading-relaxed pr-4 font-light py-2">
                              {item.desc}
                            </p>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Side: Visual */}
          <div className="w-full lg:w-3/5 relative flex items-center justify-center overflow-hidden group p-5 self-stretch rounded-[20px]">
            <img 
              alt="Atmospheric landscape" 
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105" 
              src={reversed 
                ? "https://images.unsplash.com/photo-1483728642387-6c3abe6c6b22?q=80&w=2070&auto=format&fit=crop"
                : "https://images.unsplash.com/photo-1564107628966-daff03746bee?q=80&w=987&auto=format&fit=crop"
              } 
            />
            
            {/* Floating Card */}
            <motion.div 
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              className="relative z-10 w-full max-w-lg backdrop-blur-xl border border-white/20 rounded-[20px] overflow-hidden shadow-2xl bg-white/80 mx-4"
            >
              {!reversed ? <DashboardMock /> : <CodeMock />}
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}

function DashboardMock() {
  return (
    <>
      <div className="p-4 border-b border-black/5 flex items-center justify-between bg-white/50">
        <div className="flex items-center gap-4">
          <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-blue-400 to-purple-500 animate-pulse"></div>
          <div className="flex gap-1.5">
            <div className="w-2 h-2 rounded-full bg-black/20"></div>
            <div className="w-2 h-2 rounded-full bg-black/20"></div>
          </div>
        </div>
        <div className="text-[10px] uppercase tracking-widest text-black/50 font-semibold">analytics_dashboard.io</div>
      </div>
      <div className="p-8 flex flex-col gap-8">
        <div className="grid grid-cols-3 gap-4">
          <div className="space-y-1">
            <div className="text-[10px] text-black/50 uppercase tracking-wider">Retention</div>
            <div className="text-xl font-light text-black">94.2%</div>
            <div className="h-1 w-full bg-black/5 rounded-full overflow-hidden">
              <div className="h-full bg-black/40 w-[94%]"></div>
            </div>
          </div>
          <div className="space-y-1">
            <div className="text-[10px] text-black/50 uppercase tracking-wider">Engagement</div>
            <div className="text-xl font-light text-black">+12.4%</div>
            <div className="h-1 w-full bg-black/5 rounded-full overflow-hidden">
              <div className="h-full bg-black/40 w-[65%]"></div>
            </div>
          </div>
          <div className="space-y-1">
            <div className="text-[10px] text-black/50 uppercase tracking-wider">Focus Score</div>
            <div className="text-xl font-light text-black">8.8</div>
            <div className="h-1 w-full bg-black/5 rounded-full overflow-hidden">
              <div className="h-full bg-black/40 w-[88%]"></div>
            </div>
          </div>
        </div>
        
        <div className="relative h-48 w-full border-l border-b border-black/10 flex items-end justify-between px-2 pb-2">
           {[40, 65, 30, 85, 50, 75, 20, 60, 45].map((h, i) => (
             <div key={i} className="relative z-10 w-4 bg-black/30 rounded-t-sm" style={{ height: `${h}%` }}></div>
           ))}
        </div>
      </div>
    </>
  )
}

function CodeMock() {
  return (
    <>
      <div className="p-4 border-b border-black/5 flex items-center justify-between bg-white/50">
        <div className="flex items-center gap-4">
          <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-rose-400 to-orange-500 animate-pulse"></div>
          <div className="flex gap-1.5">
            <div className="w-3 h-3 rounded-full bg-red-400"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
            <div className="w-3 h-3 rounded-full bg-green-400"></div>
          </div>
        </div>
        <div className="text-[10px] uppercase tracking-widest text-black/50 font-semibold">insight_generator.js</div>
      </div>
      <div className="p-8 font-mono text-sm leading-relaxed overflow-x-auto text-black/80">
        <div className="flex gap-4"><div className="text-black/30 select-none text-right w-4">1</div><div><span className="text-purple-600">async function</span> <span className="text-blue-600">generateInsight</span>(context) {'{'}</div></div>
        <div className="flex gap-4"><div className="text-black/30 select-none text-right w-4">2</div><div className="pl-4"><span className="text-purple-600">const</span> patterns = <span className="text-purple-600">await</span> AI.<span className="text-blue-600">analyze</span>(context.data);</div></div>
        <div className="flex gap-4"><div className="text-black/30 select-none text-right w-4">3</div><div className="pl-4"></div></div>
        <div className="flex gap-4"><div className="text-black/30 select-none text-right w-4">4</div><div className="pl-4"><span className="text-purple-600">return</span> patterns.<span className="text-blue-600">map</span>(p =&gt; ({'{'}</div></div>
        <div className="flex gap-4"><div className="text-black/30 select-none text-right w-4">5</div><div className="pl-8">title: p.concept,</div></div>
        <div className="flex gap-4"><div className="text-black/30 select-none text-right w-4">6</div><div className="pl-8">confidence: <span className="text-amber-600">0.98</span>,</div></div>
        <div className="flex gap-4"><div className="text-black/30 select-none text-right w-4">7</div><div className="pl-8">relevance: <span className="text-green-600">'high'</span></div></div>
        <div className="flex gap-4"><div className="text-black/30 select-none text-right w-4">8</div><div className="pl-4">{'}'}));</div></div>
        <div className="flex gap-4"><div className="text-black/30 select-none text-right w-4">9</div><div>{'}'}</div></div>
      </div>
    </>
  )
}
