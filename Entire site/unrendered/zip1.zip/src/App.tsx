/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Hero from './components/Hero';
import CourseIntro from './components/CourseIntro';
import LogoTicker from './components/LogoTicker';
import SmartInsights from './components/SmartInsights';
import Interstitial from './components/Interstitial';
import FeaturesGrid from './components/FeaturesGrid';
import SignOff from './components/SignOff';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-background">
      <main className="w-full">
        <Hero />
        <CourseIntro />
        <LogoTicker />
        <SmartInsights />
        <Interstitial />
        <SmartInsights reversed={true} />
        <FeaturesGrid />
        <SignOff />
      </main>
      <Footer />
    </div>
  );
}
