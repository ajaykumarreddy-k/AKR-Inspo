/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Navbar, Footer } from './components/Layout';
import { Hero, TrustStrip, Manifesto } from './components/CoreSections';
import { Collage } from './components/CollageSection';
import { BrandOS, Studio } from './components/ProductSections';
import { UseCases, Testimonial, Updates, Cta } from './components/MarketingSections';

export default function App() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <TrustStrip />
        <Collage />
        <Manifesto />
        <BrandOS />
        <Studio />
        <UseCases />
        <Testimonial />
        <Updates />
        <Cta />
      </main>
      <Footer />
    </>
  );
}
