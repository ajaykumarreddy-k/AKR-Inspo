import { motion } from 'motion/react';

export function BrandOS() {
  return (
    <section className="py-[120px] px-margin max-w-[1728px] mx-auto bg-page-bg">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-[100px] items-center">
        <motion.div 
          initial={{ opacity: 0, x: -40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="bg-gradient-to-br from-soft-card-2 to-soft-card rounded-[40px] p-8 h-[700px] flex items-center justify-center relative overflow-hidden border border-line/30 shadow-sm"
        >
          <div className="w-full max-w-md bg-white-card rounded-2xl shadow-xl border border-line/20 p-6">
            <div className="flex items-center justify-between mb-8">
              <span className="font-label font-bold text-sm text-text">Files</span>
              <span className="material-symbols-outlined text-muted">more_horiz</span>
            </div>
            <div className="space-y-4">
              <div className="flex items-center gap-4 p-3 hover:bg-soft-card rounded-xl transition-colors cursor-pointer">
                <span className="material-symbols-outlined text-[#FF4B2B]">folder</span>
                <span className="font-body-md font-medium text-text">Lumio_Strategy</span>
              </div>
              <div className="flex items-center gap-4 p-3 hover:bg-soft-card rounded-xl transition-colors cursor-pointer">
                <span className="material-symbols-outlined text-[#8A2387]">description</span>
                <span className="font-body-md font-medium text-text">BrandBook_v2</span>
              </div>
              <div className="flex items-center gap-4 p-3 hover:bg-soft-card rounded-xl transition-colors cursor-pointer">
                <span className="material-symbols-outlined text-[#E94057]">image</span>
                <span className="font-body-md font-medium text-text">Campaign_Assets</span>
              </div>
              <div className="flex items-center gap-4 p-3 hover:bg-soft-card rounded-xl transition-colors cursor-pointer">
                <span className="material-symbols-outlined text-[#F27121]">analytics</span>
                <span className="font-body-md font-medium text-text">Q3_Performance</span>
              </div>
            </div>
          </div>
        </motion.div>
        
        <div className="flex flex-col justify-center h-full max-w-lg">
          <motion.h3 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="font-display text-h2 mb-12 font-bold tracking-tight text-text"
          >
            The intelligent foundation for your brand.
          </motion.h3>
          
          <div className="relative pl-8 border-l-[3px] border-line space-y-12">
            <motion.div 
              initial={{ height: 0 }}
              whileInView={{ height: "33%" }}
              viewport={{ once: true }}
              transition={{ duration: 1, delay: 0.5 }}
              className="absolute left-[-3px] top-0 w-[3px] bg-gradient-to-b from-[#FF416C] to-[#FF4B2B]"
            />
            
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <h4 className="font-h3 text-xl font-bold mb-3 text-text">Centralized Knowledge</h4>
              <p className="font-body-md text-muted leading-relaxed">Bring all your disparate assets, guidelines, and strategic documents into one cohesive, searchable environment.</p>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 0.5, x: 0 }}
              whileHover={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="cursor-default"
            >
              <h4 className="font-h3 text-xl font-bold mb-3 text-text">Contextual Intelligence</h4>
              <p className="font-body-md text-muted leading-relaxed">Our AI understands the nuances of your brand, providing contextual recommendations and surfacing relevant assets.</p>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 0.5, x: 0 }}
              whileHover={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.6 }}
              className="cursor-default"
            >
              <h4 className="font-h3 text-xl font-bold mb-3 text-text">Seamless Distribution</h4>
              <p className="font-body-md text-muted leading-relaxed">Ensure every team member and external partner has access to the latest, approved brand materials instantly.</p>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}

export function Studio() {
  return (
    <section className="py-[120px] px-margin max-w-[1728px] mx-auto bg-page-bg">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-[100px] items-center">
        <div className="flex flex-col justify-center h-full max-w-lg order-2 lg:order-1">
          <motion.h3 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="font-display text-h2 mb-12 font-bold tracking-tight text-text"
          >
            Generate on-brand assets in seconds.
          </motion.h3>
        </div>
        
        <motion.div 
          initial={{ opacity: 0, x: 40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="bg-gradient-to-tr from-[#E0EAFC] to-[#CFDEF3] rounded-[40px] p-8 h-[700px] flex items-center justify-center relative overflow-hidden border border-line/30 shadow-inner order-1 lg:order-2"
        >
          <div className="w-full max-w-lg bg-white/80 backdrop-blur-xl rounded-3xl shadow-2xl p-8 border border-white/50">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-[24px] h-[24px] rounded-full border border-black flex items-center justify-center shrink-0">
                <span className="text-black font-bold text-[10px] leading-none">L</span>
              </div>
              <span className="font-label text-xs font-bold text-muted">LUMIO STUDIO</span>
            </div>
            
            <div className="bg-white/60 backdrop-blur-md rounded-xl p-4 mb-6 border border-white/50 shadow-sm">
              <p className="font-body-md text-text">Draft a product announcement email for the new 'Pro' tier, adopting our confident but approachable tone.</p>
            </div>
            
            <div className="flex justify-end">
              <motion.div 
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
                className="w-8 h-8 rounded-full bg-gradient-to-r from-[#FF416C] to-[#FF4B2B] flex items-center justify-center shadow-md cursor-pointer"
              >
                <span className="material-symbols-outlined text-white text-sm">auto_awesome</span>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
