import { motion } from 'motion/react';

export function UseCases() {
  return (
    <section className="py-[160px] px-margin max-w-[1728px] mx-auto flex flex-col items-center bg-page-bg">
      <motion.h2 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="font-display text-h2 mb-12 font-bold tracking-tight text-center text-text"
      >
        Built for every team.
      </motion.h2>
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ delay: 0.2 }}
        className="flex flex-wrap justify-center gap-3 mb-16"
      >
        <button className="px-6 py-2 rounded-full bg-black text-page-bg font-label text-sm shadow-md transition-colors hover:bg-black/80">Strategy</button>
        <button className="px-6 py-2 rounded-full bg-white text-text font-label text-sm hover:bg-gray-50 transition-colors shadow-sm">Marketing</button>
        <button className="px-6 py-2 rounded-full bg-white text-text font-label text-sm hover:bg-gray-50 transition-colors shadow-sm">Design</button>
        <button className="px-6 py-2 rounded-full bg-white text-text font-label text-sm hover:bg-gray-50 transition-colors shadow-sm">Sales</button>
      </motion.div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full">
        {/* Card 1 */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-white h-[400px] rounded-[32px] p-8 flex flex-col justify-between group overflow-hidden relative shadow-sm border border-line/20"
        >
          <div className="relative z-10">
            <h4 className="font-h3 text-xl font-bold mb-2 text-text">Campaign Briefs</h4>
            <p className="font-body-md text-muted">Generate comprehensive briefs aligned with brand strategy.</p>
          </div>
          <div className="absolute bottom-[-20px] right-[-20px] w-2/3 h-2/3 bg-white-card rounded-tl-3xl shadow-[0_8px_30px_rgb(0,0,0,0.12)] border border-line/10 p-6 transform group-hover:-translate-y-2 group-hover:-translate-x-2 transition-transform duration-500">
            <div className="h-3 w-1/2 bg-gradient-to-r from-[#FF416C] to-[#FF4B2B] rounded-full mb-4"></div>
            <div className="h-2 w-full bg-line/50 rounded-full mb-3"></div>
            <div className="h-2 w-5/6 bg-line/50 rounded-full mb-3"></div>
          </div>
        </motion.div>

        {/* Card 2 */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="bg-gradient-to-br from-[#FFDEE9] to-[#B5FFFC] h-[400px] rounded-[32px] p-8 flex flex-col justify-between group overflow-hidden relative shadow-sm"
        >
          <div className="relative z-10">
            <h4 className="font-h3 text-xl font-bold mb-2 text-text">Social Assets</h4>
            <p className="font-body-md text-muted">Ensure visual consistency across all channels.</p>
          </div>
          <div className="absolute bottom-[-20px] right-[-20px] w-2/3 h-2/3 bg-panel-bg rounded-tl-3xl shadow-[0_8px_30px_rgb(0,0,0,0.12)] border border-white/50 overflow-hidden transform group-hover:-translate-y-2 group-hover:-translate-x-2 transition-transform duration-500">
            <img className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuABa0q5BJ_DreMgIZGB-8at3sYpuFks_tT431tznVrVWB2C49LzdUC651wzXTj9LD-7VYCWRRpo9bqyyAQ_b54KnjtoPjXSRfeIXbBgjwHXIr8Ojo51Y8MG8CC0mGtvupgQSf4RnLcvReiqPWlUs5L2KkemFlhV-MfAQAzfyxIvGWfFM2Orh3ChuU5A6sOS2VBQbJyPWAQcwMlr6YWpCbln_V8DC4Yo90e6mK4QAINc-FrScaJ_KPin-t6UJ12p4Dnl5CbWpvGS2GiO"/>
          </div>
        </motion.div>

        {/* Card 3 */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="bg-white h-[400px] rounded-[32px] p-8 flex flex-col justify-between group overflow-hidden relative border border-line/20 shadow-sm"
        >
          <div className="relative z-10">
            <h4 className="font-h3 text-xl font-bold mb-2 text-text">Sales Decks</h4>
            <p className="font-body-md text-muted">Empower reps with up-to-date, on-brand messaging.</p>
          </div>
          <div className="absolute bottom-[-20px] right-[-20px] w-2/3 h-2/3 bg-page-bg rounded-tl-3xl shadow-[0_8px_30px_rgb(0,0,0,0.12)] border border-line/10 p-6 transform group-hover:-translate-y-2 group-hover:-translate-x-2 transition-transform duration-500 flex flex-col gap-3">
            <div className="w-full h-1/2 bg-gradient-to-r from-[#8A2387] to-[#E94057] rounded-lg"></div>
            <div className="w-full h-1/2 bg-soft-card rounded-lg flex gap-2">
              <div className="w-1/2 h-full bg-line/30 rounded-md"></div>
              <div className="w-1/2 h-full bg-line/30 rounded-md"></div>
            </div>
          </div>
        </motion.div>

        {/* Card 4 */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          className="bg-[#181818] h-[400px] rounded-[32px] p-8 flex flex-col justify-between group overflow-hidden relative shadow-lg"
        >
          <div className="relative z-10">
            <h4 className="font-h3 text-xl font-bold mb-2 text-white">Voice Guidelines</h4>
            <p className="font-body-md text-white/70">Codify your brand's unique tone and terminology.</p>
          </div>
          <div className="absolute bottom-[20px] right-[20px] w-1/2 h-1/2 bg-gradient-to-br from-[#f12711] to-[#f5af19] rounded-2xl shadow-xl p-6 transform group-hover:scale-105 transition-transform duration-500 flex items-center justify-center">
            <span className="material-symbols-outlined text-white text-[48px]">record_voice_over</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

export function Testimonial() {
  return (
    <section className="py-[160px] px-margin max-w-[1200px] mx-auto flex flex-col items-center text-center bg-page-bg">
      <motion.div 
        initial={{ opacity: 0, scale: 0.5 }}
        whileInView={{ opacity: 0.3, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="mb-12 text-transparent bg-clip-text bg-gradient-to-r from-[#FF416C] to-[#FF4B2B]"
      >
        <span className="material-symbols-outlined text-[64px]">format_quote</span>
      </motion.div>
      
      <motion.h2 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, delay: 0.2 }}
        className="font-display text-[40px] md:text-[56px] leading-[1.1] font-bold tracking-tight text-text mb-16 text-balance"
      >
        "Lumio was built with the desire to liberate creative teams from menial tasks, allowing them to focus on true strategic innovation."
      </motion.h2>
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, delay: 0.4 }}
        className="flex items-center gap-4"
      >
        <div className="w-14 h-14 rounded-full bg-line overflow-hidden shadow-md">
          <img className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuD_dQOYUXm-9ocUk-1cRA5ZyP6tu7OdWwNIU7SRhouWt3u89anzj3A5_pr7FGCCICOiz6a2FoSpC-bN53AYbiVQ-spgKPawBtGZtLq-9c6QyNclym7oEuOsCnQllJenEGuMkAeM3mwnTOLdgJakEE63ozCYcDA2l-C2EQnZiozAakUbDrwJG_jxTwrvV9I5p2oiVPXIDBv-rltdG9P0TX6X2OUHQcwckpskXXJEawplcI8ff_rzn1YnIDgrniF27Vjc0Lz4LKcazue9"/>
        </div>
        <div className="text-left">
          <p className="font-label text-sm font-bold text-text">Alex Morgan</p>
          <p className="font-label text-xs text-muted">VP of Brand, Northline</p>
        </div>
      </motion.div>
    </section>
  );
}

export function Updates() {
  return (
    <section className="py-[120px] px-margin max-w-[1728px] mx-auto bg-page-bg">
      <div className="flex justify-between items-end mb-12">
        <h2 className="font-display text-h2 font-bold tracking-tight text-text">Latest Updates</h2>
        <button className="font-label text-sm font-bold border-b border-black text-text pb-1 hover:text-[#FF416C] hover:border-[#FF416C] transition-colors">
          View All
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="group cursor-pointer"
        >
          <div className="w-full h-[450px] bg-panel-bg rounded-[32px] mb-6 overflow-hidden shadow-md">
            <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBSO7q5jBNOT3hqLKDm3SBl2gq1FNkbf3A6w7XGvW-FczLOWzsAngi8ITvcu3ZVz8p1PlS2O8BLLcKUcYY3CKY63FLoeynerMHqQUW1679c6oPyUe-ZT7m5zc5uDN9f-3BQLDY9Z7b73BTUzr4SmYNxUrw3XFXzKSbTz-_6dpzkjmI40NML8wW37GAhFhQKr6JYxr2EPsuNY8KoBwVPVrs0HJaDY6amCLg5iO1GmiVcZvL41NWY2Bn0LZNm-lk3Yt6Vk0N6SGuriNbj"/>
          </div>
          <p className="font-label text-xs text-muted mb-3">Product Update • Oct 12</p>
          <h4 className="font-h3 text-xl font-bold text-text group-hover:text-[#FF416C] transition-colors">Introducing Lumio Studio Analytics</h4>
        </motion.div>
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="group cursor-pointer"
        >
          <div className="w-full h-[450px] bg-soft-card rounded-[32px] mb-6 overflow-hidden shadow-md">
            <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCpG6adVPxKZeeK9eJ2dK9tUanRlhk8_krZDoEDsafUQ9gt2Yyc3YsfqK4_I23s6a-cqJRRE4Y6kyCMgihqtNrrwvRDs2u9N5xn3Vmo77U2yYOslnbl8oALfBx2hQnDRcw2t-epqcBs21ooh_k46gNLaJs7-fK4J6qNNMW5ScFLhb5EL12iPGYhQEirD7se3PkbCfglYnhMqf-zCubvEnv_dINqdjLPj_S13Fr0HeMXaxhn9AqfDqqdGC7Bl-2OYqfwfbyoyRGodLCY"/>
          </div>
          <p className="font-label text-xs text-muted mb-3">Guide • Sep 28</p>
          <h4 className="font-h3 text-xl font-bold text-text group-hover:text-[#FF416C] transition-colors">The Modern Brand Architecture</h4>
        </motion.div>
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4 }}
          className="group cursor-pointer"
        >
          <div className="w-full h-[450px] bg-panel-bg rounded-[32px] mb-6 overflow-hidden shadow-md">
            <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDJaqzd1zJdXX1EdZhbTwql0mVIvsGXueArpb4dyIw4esyXpBY8wHK5JFAojAFJUPAIhbjpuOoYEDNE8l605KW6euYmMCfS48bPI1HvdevuWn7Nz8VwfPIiJOMHuDVxrM6Y3W-iETid73M2yg3TIIPdazulPFgqx1UguSzfxU_s4S-q4mEvXX9AZ4hWtDx_vyn_dBZnS5o9AAuLJYnkmY-AjcFw3apWVyaF23rST8wE9U0w261HX2sRI4MBqiquoRVKZrNvFj0BbpTe"/>
          </div>
          <p className="font-label text-xs text-muted mb-3">Company • Sep 15</p>
          <h4 className="font-h3 text-xl font-bold text-text group-hover:text-[#FF416C] transition-colors">Lumio raises Series B to expand AI</h4>
        </motion.div>
      </div>
    </section>
  );
}

export function Cta() {
  return (
    <section className="py-[160px] px-margin max-w-[1728px] mx-auto flex flex-col items-center text-center bg-page-bg">
      <motion.div 
        initial={{ opacity: 0, scale: 0.5 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, type: "spring" }}
        className="w-[120px] h-[120px] rounded-full border border-black flex items-center justify-center mb-12"
      >
        <span className="text-black font-bold text-[64px] leading-none">L</span>
      </motion.div>
      
      <motion.h2 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="font-display text-[56px] leading-[1.1] font-bold tracking-tight text-text mb-8 max-w-3xl text-balance"
      >
        Get a personalized demo of Lumio.
      </motion.h2>
      
      <motion.button 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: 0.4 }}
        className="bg-black text-page-bg font-label text-sm px-10 py-5 rounded-full hover:bg-black/80 transition-all shadow-lg hover:shadow-xl hover:-translate-y-1 transform duration-300"
      >
        Schedule a call
      </motion.button>
    </section>
  );
}
