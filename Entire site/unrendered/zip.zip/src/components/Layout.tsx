import { ReactNode } from 'react';

export function Navbar() {
  return (
    <header className="fixed top-[24px] left-0 right-0 z-50 flex items-center justify-center px-sm w-full pointer-events-none">
      <div className="pointer-events-auto w-full max-w-[700px] h-[72px] flex items-center justify-between bg-[#000000] backdrop-blur-xl rounded-full px-xs py-xs shadow-xl border border-white/10">
        <div className="flex items-center gap-md pl-xs">
          <div className="w-[34px] h-[34px] rounded-full border border-page-bg/80 flex items-center justify-center shrink-0">
            <span className="text-page-bg font-bold text-sm leading-none">L</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <a className="font-label text-label text-page-bg/80 hover:text-page-bg transition-colors duration-300" href="#">Product</a>
            <a className="font-label text-label text-page-bg/80 hover:text-page-bg transition-colors duration-300" href="#">Solutions</a>
            <a className="font-label text-label text-page-bg/80 hover:text-page-bg transition-colors duration-300" href="#">About</a>
            <a className="font-label text-label text-page-bg/80 hover:text-page-bg transition-colors duration-300" href="#">Blog</a>
          </nav>
        </div>
        <button className="bg-page-bg text-black font-label text-label h-full px-8 rounded-full hover:bg-white transition-colors duration-300 scale-95 hover:scale-100 shrink-0 flex items-center shadow-sm">
          Book a demo
        </button>
      </div>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="bg-gradient-to-b from-[#181818] to-[#0a0a0a] text-page-bg font-body-md text-body-md w-full pt-12 pb-xl px-margin flex flex-col items-center rounded-t-[40px] mt-section relative overflow-hidden">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent"></div>
      <div className="max-w-[1728px] mx-auto w-full relative z-10">
        {/* Inverted Capsule Nav */}
        <div className="w-full max-w-[700px] mx-auto h-[72px] flex items-center justify-between bg-white/10 backdrop-blur-md rounded-full px-xs py-xs mb-[120px] shadow-lg border border-white/10">
          <div className="flex items-center gap-md pl-xs">
            <div className="w-[34px] h-[34px] rounded-full border border-white flex items-center justify-center shrink-0">
              <span className="text-white font-bold text-sm leading-none">L</span>
            </div>
            <nav className="hidden md:flex items-center gap-6">
              <a className="font-label text-label text-white/80 hover:text-white transition-colors duration-300" href="#">Product</a>
              <a className="font-label text-label text-white/80 hover:text-white transition-colors duration-300" href="#">Solutions</a>
              <a className="font-label text-label text-white/80 hover:text-white transition-colors duration-300" href="#">About</a>
              <a className="font-label text-label text-white/80 hover:text-white transition-colors duration-300" href="#">Blog</a>
            </nav>
          </div>
          <button className="bg-white text-black font-label text-label h-full px-8 rounded-full hover:bg-gray-100 transition-colors duration-300 scale-95 hover:scale-100 shrink-0 flex items-center shadow-sm">
            Book a demo
          </button>
        </div>
        
        <div className="flex flex-col items-center mb-[120px]">
          <div className="w-[180px] h-[180px] rounded-full border border-white/40 flex items-center justify-center mb-8">
            <span className="text-white font-bold text-[96px] leading-none">L</span>
          </div>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-lg w-full mb-xl text-left border-t border-white/10 pt-16 text-white">
          <div className="flex flex-col gap-4">
            <h4 className="font-label text-label text-white/50 uppercase mb-2">Product</h4>
            <a className="hover:text-white transition-colors text-white/80" href="#">Features</a>
            <a className="hover:text-white transition-colors text-white/80" href="#">Integrations</a>
            <a className="hover:text-white transition-colors text-white/80" href="#">Pricing</a>
            <a className="hover:text-white transition-colors text-white/80" href="#">Changelog</a>
          </div>
          <div className="flex flex-col gap-4">
            <h4 className="font-label text-label text-white/50 uppercase mb-2">Solutions</h4>
            <a className="hover:text-white transition-colors text-white/80" href="#">Marketing</a>
            <a className="hover:text-white transition-colors text-white/80" href="#">Design</a>
            <a className="hover:text-white transition-colors text-white/80" href="#">Strategy</a>
            <a className="hover:text-white transition-colors text-white/80" href="#">Agencies</a>
          </div>
          <div className="flex flex-col gap-4">
            <h4 className="font-label text-label text-white/50 uppercase mb-2">Company</h4>
            <a className="hover:text-white transition-colors text-white/80" href="#">About Us</a>
            <a className="hover:text-white transition-colors text-white/80" href="#">Careers</a>
            <a className="hover:text-white transition-colors text-white/80" href="#">Blog</a>
            <a className="hover:text-white transition-colors text-white/80" href="#">Contact</a>
          </div>
          <div className="flex flex-col gap-4">
            <h4 className="font-label text-label text-white/50 uppercase mb-2">Legal</h4>
            <a className="hover:text-white transition-colors text-white/80" href="#">Privacy Policy</a>
            <a className="hover:text-white transition-colors text-white/80" href="#">Terms of Service</a>
            <a className="hover:text-white transition-colors text-white/80" href="#">Cookie Policy</a>
          </div>
          <div className="flex flex-col gap-4">
            <h4 className="font-label text-label text-white/50 uppercase mb-2">Social</h4>
            <a className="hover:text-white transition-colors text-white/80" href="#">Twitter / X</a>
            <a className="hover:text-white transition-colors text-white/80" href="#">LinkedIn</a>
            <a className="hover:text-white transition-colors text-white/80" href="#">Instagram</a>
          </div>
          <div className="flex flex-col gap-4">
            <h4 className="font-label text-label text-white/50 uppercase mb-2">Support</h4>
            <a className="hover:text-white transition-colors text-white/80" href="#">Help Center</a>
            <a className="hover:text-white transition-colors text-white/80" href="#">Community</a>
            <a className="hover:text-white transition-colors text-white/80" href="#">API Docs</a>
          </div>
          <div className="flex flex-col gap-4">
            <h4 className="font-label text-label text-white/50 uppercase mb-2">Security</h4>
            <a className="hover:text-white transition-colors text-white/80" href="#">Trust Center</a>
            <a className="hover:text-white transition-colors text-white/80" href="#">Compliance</a>
            <div className="flex items-center gap-2 text-white/80 hover:text-white transition-colors cursor-pointer">
              <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.5)]"></div>
              <span>Operational</span>
            </div>
          </div>
        </div>
        
        <div className="flex flex-col md:flex-row items-center justify-between w-full pt-8 text-white/50 text-sm border-t border-white/10">
          <p>© 2024 Lumio. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
