import { motion } from 'motion/react';

export function Hero() {
  return (
    <section className="pt-[240px] px-margin max-w-[1728px] mx-auto flex flex-col items-center text-center relative overflow-visible bg-page-bg h-[1100px]">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="font-display text-display text-balance max-w-4xl mb-lg text-text tracking-tighter"
      >
        Bring every team into focus
      </motion.h1>
      <p className="font-body-lg text-body-lg text-muted max-w-2xl mb-lg hidden">
        Decode your lorem ipsum DNA. Bring absolute clarity to your organization's most critical assets with a platform designed for deep focus.
      </p>
      <button className="bg-black text-page-bg font-label text-label px-8 py-4 rounded-full hover:bg-black/90 transition-opacity mb-[80px] hidden">
        Get started
      </button>
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-[1492px] bg-panel-bg overflow-hidden shadow-2xl relative z-10 rounded-[40px] h-[800px]"
      >
        <img 
          alt="Vibrant abstract gradient" 
          className="w-full h-full object-cover" 
          src="https://lh3.googleusercontent.com/aida-public/AB6AXuCZfadtPwCaL7GcKGqde5_m46RsgQuGHyvmFJKZWsW5jfFqnNirmZPOdmGitXGSosoyvd2ARpUMWjjL8IEKefG6Ke85eAGiFMBHIfFA02wVwfcf75CnI7Zlw-OjEat9LRRuqHbfAWLeBZeTEUbVQRAoPIjSlWUOZmW8R32Bk0XUblejaVIpv6gSC4cngTCtp7tXSmIz5jJIUVZIPoKSyGDhck_ulpZZnIfCQmxw2h73JqSgD__x2T1wiMf4Q_TQCvHgDTzQ3sY3JjqV"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
      </motion.div>
    </section>
  );
}

export function TrustStrip() {
  const logos = ["Northline", "Arcform", "Velo Group", "Juniper", "Meridian"];
  
  return (
    <section className="py-xl px-margin border-t border-line/30 max-w-[1728px] mx-auto flex flex-col items-center bg-page-bg relative z-0 pt-[40px]">
      <p className="font-label text-label text-muted mb-md uppercase tracking-widest text-center hidden">
        Built with lorem ipsum leaders from
      </p>
      <div className="flex justify-center items-center opacity-[0.72] text-muted-light w-full">
        <div className="marquee-container">
          <div className="marquee-content flex gap-[100px] items-center text-muted-light">
            {[...logos, ...logos].map((logo, index) => (
              <span 
                key={index} 
                className="font-h3 text-h3 font-semibold tracking-tight opacity-40 grayscale hover:opacity-100 hover:grayscale-0 transition-all duration-300 cursor-default"
              >
                {logo}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

export function Manifesto() {
  return (
    <section className="py-[200px] px-margin max-w-[1728px] mx-auto relative flex flex-col items-center text-center bg-page-bg">
      <div className="absolute top-0 right-[10%] w-[400px] h-[400px] opacity-10 pointer-events-none">
        <svg className="w-full h-full" fill="none" stroke="url(#manifesto-grad)" strokeWidth="0.5" viewBox="0 0 100 100">
          <defs>
            <linearGradient id="manifesto-grad" x1="0%" x2="100%" y1="0%" y2="100%">
              <stop offset="0%" stopColor="#FF416C"></stop>
              <stop offset="100%" stopColor="#FF4B2B"></stop>
            </linearGradient>
          </defs>
          <circle cx="50" cy="50" r="48"></circle>
          <ellipse cx="50" cy="50" rx="24" ry="48"></ellipse>
          <ellipse cx="50" cy="50" rx="48" ry="24"></ellipse>
          <line x1="2" x2="98" y1="50" y2="50"></line>
          <line x1="50" x2="50" y1="2" y2="98"></line>
        </svg>
      </div>
      
      <motion.h2 
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.8 }}
        className="font-display text-[49px] leading-[1.1] text-balance max-w-[1200px] font-bold tracking-tight text-text relative z-10"
      >
        As lorem ipsum agents expand across the enterprise, the need for a singular source of truth has never been more critical. Lumio unifies your strategy.
      </motion.h2>
    </section>
  );
}
