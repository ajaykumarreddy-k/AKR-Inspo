import { motion, useScroll, useTransform } from 'motion/react';
import { useRef } from 'react';

export function Collage() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  // Parallax effects for different elements to give depth
  const y1 = useTransform(scrollYProgress, [0, 1], [50, -50]);
  const y2 = useTransform(scrollYProgress, [0, 1], [-20, 80]);
  const y3 = useTransform(scrollYProgress, [0, 1], [80, -80]);
  const y4 = useTransform(scrollYProgress, [0, 1], [-50, 50]);

  return (
    <section ref={containerRef} className="min-h-[1400px] w-full max-w-[1728px] mx-auto relative overflow-hidden bg-page-bg py-xl">
      {/* Central Anchor */}
      <div className="absolute inset-0 flex items-center justify-center z-10 pointer-events-none">
        <motion.h2 
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="font-display text-[120px] font-bold text-text tracking-tighter leading-[0.9] text-center"
        >
          Creative<br/>Intelligence
        </motion.h2>
      </div>

      {/* 1. Top-left */}
      <motion.div 
        style={{ y: y1 }}
        className="absolute rounded-[24px] overflow-hidden bg-panel-bg shadow-xl" 
        initial={{ opacity: 0, x: -50 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, delay: 0.1 }}
        style={{ left: '8%', top: '5%', width: '270px', height: '210px', y: y1 }}
      >
        <img className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDGxwLNMP2KVAWtuqvWXiFZkBm5YgSXjM45PkkRPvB3NsuAPX4Nse6nAySmOSPxXiaWvlTk0fB0Pagx0EkNf1L8x3CFyxgAWpQbdP2z4ZXhaiVorAeLCKBcI2qvs9oG9HqdMdiJrUYvBgL1Dr8nKNzygffqFMIlgWyshucf41s65I_hV3kCGtjFYShml4zOn9O6MuvVW54WVcjP7bBLEAYguBfutmc0Yq73HP9-yBiY6b98be0hC6KYAZFesHH3FkL4Gx0Yks2fyrpu"/>
      </motion.div>

      {/* 2. Top-right */}
      <motion.div 
        className="absolute rounded-[24px] overflow-hidden bg-panel-bg shadow-xl" 
        initial={{ opacity: 0, x: 50 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, delay: 0.2 }}
        style={{ right: '8%', top: '2%', width: '290px', height: '260px', y: y2 }}
      >
        <img className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDRI6ZfedfqJ42Kz8fkZTlqC5CbQ5Q_0kVkLxIu7Xh8-ABjTl2K4v_yJEBQE1wi3AZMYD9IMvFxFOJyc86piFVAfQ0g6nyc1fRoYl7wB1_YDB3zlrCqOGtEow28qlTRV6LL9s1-rRPvAYojJgQhjJ9ERQ7Jf-IhHeg0bAcA4QWd3YKyDnVxSjTGeJ--ir7xqCghMtZPJ5OjvBwWSTiw7xPHbFrwOa_f5RTQGV6WOEWxuC-xwV7Ayb1q0kBzYF_oQHCxP3Dn3PL-aewa"/>
      </motion.div>

      {/* 3. Left-middle */}
      <motion.div 
        className="absolute rounded-[24px] overflow-hidden bg-panel-bg relative shadow-xl z-20" 
        initial={{ opacity: 0, scale: 0.9 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, delay: 0.3 }}
        style={{ left: '5%', top: '35%', width: '330px', height: '200px', y: y3 }}
      >
        <img className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCI3qPhz21Acw0AbNlBUPm0zvO8i2YhSwVSCeymxT8B-DK9LFeue5NmI6rZOMlmi63aYlpF6sctE4Z6nVQyKbzDNPzBxfmlYqn2sWwM4Ny41RsY8lWjp6XZq3EQaQ9OBTiCr79ffpaxFDfCaLYUR_NhJjMvSs6pgYKjdGmA9O9HWagTsoARXVgOdEH9uqNqZ5TYj0Y8BD5hIPyCHuYCQjYIaw57IB3NGZEOsWhia-h5PqmPglOurG6z4WNi6G5lFjSulfIHvqLLGmVd"/>
        <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-4 py-2 rounded-full">
          <span className="font-label text-xs font-semibold text-text">Content Guidelines</span>
        </div>
      </motion.div>

      {/* 4. Right-middle */}
      <motion.div 
        className="absolute rounded-[24px] overflow-hidden bg-panel-bg shadow-xl z-20" 
        initial={{ opacity: 0, scale: 0.9 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, delay: 0.4 }}
        style={{ right: '2%', top: '25%', width: '250px', height: '330px', y: y4 }}
      >
        <img className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCRd7pAyBrUx31zx6klyDiCWD04EiIaiDfNYNdGO8HozSTYH3bTc4IhWoBbOh4CpW4jAmMk2H_ecdJwzZL71ta4NvHIyMqapKo2BK36h0hn674xlIS0FoLhl6jQwDTwu_Idk9ZLj6MN8k5s-VrWMSox9J5YNpnlpqVlAVnzCXtAeDkwyvNWzXtGXt76wUk85CfXUmdE9Vi6RxqxkyBORzc1__OdpVEqiYNrMD1dKFJIU7gC874F--k_Kf5C1_yMSnhoytWkS9XWPwsm"/>
      </motion.div>

      {/* 5. Center-lower */}
      <motion.div 
        className="absolute rounded-[24px] overflow-hidden bg-black z-0 shadow-2xl" 
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, delay: 0.5 }}
        style={{ left: '55%', top: '70%', width: '370px', height: '250px', y: y1 }}
      >
        <img className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuB1JNPrOdnXlUzdJF3xsLHezyvtNiP-I2bNeN_ZmsjulJHHaMG8LFiwvg-ClLM09DHJPdktxAX9r8PlmDv2NT_xVXzDoCYQba-d-TPIUmGe_PnNytjbr2Z4jVDeLoGmqiYo2PI1blrti6KE4pK6yB_4qWY7eZNwxowZQz_0BTlcMJHpztmUsLT2F9XkjhbDv25Q8Ag077NWSsE93fCPUqdP7LhQkrTUTIBa6EQb3Eu3idHTuhFW2qbca7jUO2GLP6aa7Pauo0aJi8Ef"/>
      </motion.div>

      {/* 6. Floating Comment */}
      <motion.div 
        className="absolute bg-white/80 backdrop-blur-lg rounded-full flex items-center gap-3 px-4 py-3 shadow-lg border border-white/50 z-30" 
        initial={{ opacity: 0, scale: 0.5 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: 0.8, type: "spring", stiffness: 200 }}
        style={{ left: '35%', top: '78%', width: '305px', height: '62px', y: y3 }}
      >
        <div className="w-8 h-8 rounded-full bg-soft-card overflow-hidden">
          <img className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDxUZpAK7kBAK1H5Anlz-i_nh19XyaGUt1hLDC6ZASnuBK2vRcwFDP46vx7HodMWCGvWJVA3aKLfp00pDRGNPsH0LVYvOGBSQ1KJIx2wTCxFcEJMNlnv9DHJKT0wyVelxRunXJN3d41Z2MPDK4poxQF_iybQaYL4ebVjC52RWnq9U6Y-VA7k5seZ7Z4c1n3nq7ply6CwSNm8-OH_B6wae1-h-Zmn2y3jh9urDyal2zhahuy408MHHCcPTmA9TNKUOA7WEsjuEy1iMvC"/>
        </div>
        <div className="flex flex-col">
          <span className="font-label text-[10px] text-text font-bold">lorem_d</span>
          <span className="font-body-md text-[13px] text-muted leading-tight">game changing! 1h</span>
        </div>
      </motion.div>

      {/* 7. Bottom-left */}
      <motion.div 
        className="absolute rounded-[24px] overflow-hidden bg-panel-bg relative shadow-xl z-10" 
        initial={{ opacity: 0, x: -30, y: 30 }}
        whileInView={{ opacity: 1, x: 0, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, delay: 0.6 }}
        style={{ left: '4%', top: '75%', width: '340px', height: '250px', y: y2 }}
      >
        <img className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAJHfj4_xGj0yuLj8FKt6X72bCIskF-kJl3LA3T3_1-Qfv6mfKwCLXqKuU41nv1J3p_M1VLaKyUwt7jymaxu9IqrMBeOZwhDvKB2NclDw7qctzcy_CAPxlD6DRpxJ5uMf6G4nCRrvnMp59n2r2y9HaRxoemHYv9Vm4p_TMdRUwKitMvWXTR13rOY5umPLmIVd6L5RMbQMm1ZFC8-WMQdUrzWugK5J4Eh0Ph9XOn2e4G84KG4Az4KXAh3-n2Y52A1ycQ8Ow3OGXHosuz"/>
        <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm px-4 py-2 rounded-full">
          <span className="font-label text-xs font-semibold text-text">Brand Voice</span>
        </div>
      </motion.div>

      {/* 8. Bottom-right */}
      <motion.div 
        className="absolute rounded-[24px] overflow-hidden bg-panel-bg shadow-xl z-20" 
        initial={{ opacity: 0, x: 30, y: 30 }}
        whileInView={{ opacity: 1, x: 0, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, delay: 0.7 }}
        style={{ right: '5%', top: '72%', width: '410px', height: '300px', y: y4 }}
      >
        <img className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDbheL8VQt2V3qxmEXBukkZcNptuzepd42MEKEg9-qDVlpepWCcPZIR5s9MzcSFv4FH-6IuiF9uWjjxSWg2IQ-A_CdbSU7IbdGFdbRPcFqz1DyoSSA1w-kOaLoqdLsFYVQuBBDENJ0aa2OHfgIFFJ1Y7GClriULppWYz7d7fGuv-GPC_YjW-mQfwtuP1rbtxhAb-IzFfX6o7nj41jI_XdcVGj6on-6bwuQl_W5NMa4g3MvEW_sVCeo4Tgf1W3QkrnYFQKfSyl3ScLps"/>
      </motion.div>
    </section>
  );
}
