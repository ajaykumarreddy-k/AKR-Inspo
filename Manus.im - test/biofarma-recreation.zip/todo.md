- [x] Compare the proof-card rail and footer against the newly supplied reference crops.
- [x] Prevent unintended card-rail movement and preserve its stable cropped composition.
- [x] Rebuild the footer information layout and dark divisions teaser to better match the reference.
- [x] Translate visible navigation, sections, buttons, labels, and footer copy to English.
- [x] Improve smooth scrolling, section-reveal timing, and reduced-motion behavior.
- [x] Verify desktop and mobile screenshots, then save the revised checkpoint.

## Motion revision

- [x] Inspect the current rail movement requirements from the supplied crop.
- [x] Add Lenis for smooth scroll while preserving reduced-motion behavior.
- [x] Make the proof-card rail loop continuously from right to left.
- [x] Improve text-on-scroll reveals with visible staggered animation.
- [x] Verify the moving rail and text motion, then save the motion checkpoint.
