# Supplied reference crop findings

The proof-card rail is a **static horizontal composition**, not an automatically moving marquee. The reference shows partial adjacent cards at both viewport edges, a clear 20–24px gap between cards, tall 300px-ish rounded cards, and no hover lift or animated translation.

The first visible complete card is a photographic Roche card with a high-contrast white Roche emblem, a small dark-teal circular check badge at its top-right corner, a dark image-gradient legibility layer, white all-caps label text, and white descriptive copy.

The regional card is a pale, almost white panel with a dotted South America map, small circular country/status badges, pink label text, and dark-teal descriptive copy. The next card uses a real documentary photo of three staff members with the same dark lower gradient and white label/copy treatment.

The next numeric card uses a large **35x** figure with a thin outlined upward arrow, pink uppercase label, dark-teal copy, and a very pale blue-white surface. The following installations card is a photographic building image with its own dark lower gradient, white label, and white copy. The rail keeps a stable vertical alignment and uses borders with very soft grey/pink shadows rather than animated motion.

## Footer reference details

The footer is a broad, open pale-lavender content field rather than a compact dark panel. The left column begins with a dark-teal flower mark and bold two-line descriptor. A lower left block contains the short company statement, Chile/Peru country pills, and a single copyright / design-credit line. The center column is a simple vertical navigation stack, while certification badges sit at the lower middle. The next crop confirms the footer continues into separate divisions, legal, and follow-us columns, then a large dark-teal rounded “Divisions” teaser begins below the footer field.

## Motion reference

The updated proof-card crop confirms the intended card dimensions and ordering: cropped adjacent cards sit at both edges, while Roche, regional presence, consulting, and sustained-growth cards pass through the central viewport from **right to left**. The motion should be continuous and evenly paced, with no card hover lift, snaps, or changes to card height.
