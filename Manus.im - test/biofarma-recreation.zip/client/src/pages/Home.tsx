/**
 * Design reminder — Source-faithful healthcare editorial:
 * pale lavender canvas, deep teal typography, small Biofarma-pink signals,
 * oversized clinical imagery, stable proof cards, and calm layered motion.
 */
import { useEffect, useState } from "react";
import Lenis from "lenis";
import {
  ArrowRight,
  ChevronDown,
  ChevronRight,
  Facebook,
  Instagram,
  Linkedin,
  Menu,
  MoveUpRight,
  Plus,
  X,
} from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const assets = {
  symbol: "/manus-storage/biofarma-symbol_504798e8.png",
  hero: "/manus-storage/biofarma-hero-clinical_b519af4f.jpg",
  lab: "/manus-storage/biofarma-lab-service_43abec86.jpg",
  devices: "/manus-storage/biofarma-devices-service_09e940b2.jpg",
  pharma: "/manus-storage/biofarma-pharma-service_f00ff722.jpg",
};

const proofCards = [
  { kind: "number", figure: "50", suffix: "years", tag: "TRAJECTORY", copy: "More than 50 years of healthcare experience." },
  { kind: "roche", figure: "Roche", tag: "PARTNERSHIPS", copy: "Authorized distributor of Roche solutions." },
  { kind: "map", figure: "ARG · CHI · PER", tag: "REGIONAL PRESENCE", copy: "South America and Latin America." },
  { kind: "people", figure: "", tag: "CONSULTING", copy: "Professionals who support every implementation." },
  { kind: "number", figure: "35x", suffix: "↑", tag: "SUSTAINED GROWTH", copy: "Regional growth over the last 5 years." },
  { kind: "facility", figure: "", tag: "FACILITIES", copy: "1,300 m² of infrastructure and logistics capacity." },
  { kind: "number", figure: "500", suffix: "☆", tag: "TRUSTED CLIENTS", copy: "More than 500 laboratories, clinics, and healthcare organizations." },
  { kind: "team", figure: "+90", tag: "TEAM", copy: "Professionals working across the region." },
];

const loopingProofCards = [...proofCards, ...proofCards];

const services = [
  { title: "Laboratories", image: assets.lab, copy: "We support laboratories and professionals with technology that enables safer clinical decisions." },
  { title: "Medical devices", image: assets.devices, copy: "We bring practical tools that strengthen the everyday work of care teams." },
  { title: "Pharma", image: assets.pharma, copy: "Safe, effective products backed by leading brands at every stage of the clinical process." },
];

const faqs = [
  ["What is Biofarma and what does it do?", "We are a regional company integrating diagnostic, medical-device, and pharmaceutical solutions with specialized technical support for healthcare institutions."],
  ["Which countries does Biofarma operate in?", "Our coverage supports healthcare projects in Argentina, Chile, Peru, and other markets across Latin America."],
  ["How much healthcare-sector experience does Biofarma have?", "We bring more than 50 years of experience building long-term relationships with professionals, institutions, and global brands."],
  ["Which solutions does Biofarma offer?", "We work across clinical laboratories, medical devices, and pharmaceutical lines, from consultation through post-sales support."],
  ["How can I request a quote or contact Biofarma?", "You can contact us through the form or email channel, and our team will guide you according to your institution’s needs."],
  ["How can I become part of the Biofarma community?", "We share opportunities, news, and specialist content for the people moving healthcare forward across the region."],
];

function Brand({ footer = false }: { footer?: boolean }) {
  return (
    <a className={`brand ${footer ? "brand-footer" : ""}`} href="#top" aria-label="Biofarma, return to top">
      <img src={assets.symbol} alt="" className="brand-mark" />
      {!footer && <span className="brand-word">biofarma</span>}
    </a>
  );
}

function MiniArrow() {
  return <span className="accent-arrow"><ArrowRight size={16} strokeWidth={1.6} /></span>;
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [divisionsOpen, setDivisionsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let lenis: Lenis | null = null;
    let animationFrame = 0;
    const onScroll = () => window.requestAnimationFrame(() => setScrolled(window.scrollY > 18));
    const onHashLinkClick = (event: MouseEvent) => {
      const anchor = (event.target as HTMLElement).closest<HTMLAnchorElement>('a[href^="#"]');
      const href = anchor?.getAttribute("href");
      const target = href ? document.querySelector(href) : null;
      if (!target) return;
      event.preventDefault();
      if (lenis) {
        lenis.scrollTo(target as HTMLElement, { offset: -102, duration: 1.18 });
      } else {
        target.scrollIntoView({ behavior: "auto", block: "start" });
      }
      window.history.replaceState(null, "", href);
    };
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((entry) => entry.isIntersecting && entry.target.classList.add("is-visible")),
      { threshold: 0.08, rootMargin: "0px 0px -9% 0px" },
    );
    document.querySelectorAll(".reveal").forEach((element) => observer.observe(element));
    if (!reduceMotion) {
      lenis = new Lenis({
        duration: 1.18,
        easing: (time) => Math.min(1, 1.001 - Math.pow(2, -10 * time)),
        smoothWheel: true,
        syncTouch: false,
        wheelMultiplier: 0.9,
        touchMultiplier: 1.05,
      });
      lenis.on("scroll", ({ scroll }) => setScrolled(scroll > 18));
      const onAnimationFrame = (time: number) => {
        lenis?.raf(time);
        animationFrame = window.requestAnimationFrame(onAnimationFrame);
      };
      animationFrame = window.requestAnimationFrame(onAnimationFrame);
    } else {
      window.addEventListener("scroll", onScroll, { passive: true });
    }
    document.addEventListener("click", onHashLinkClick);
    onScroll();
    return () => {
      window.cancelAnimationFrame(animationFrame);
      lenis?.destroy();
      window.removeEventListener("scroll", onScroll);
      document.removeEventListener("click", onHashLinkClick);
      observer.disconnect();
    };
  }, []);

  const closeMenu = () => {
    setMenuOpen(false);
    setDivisionsOpen(false);
  };

  return (
    <main id="top" className="site-shell">
      <header className={`site-header ${scrolled ? "is-scrolled" : ""}`}>
        <div className="nav-frame">
          <Brand />
          <nav className="desktop-nav" aria-label="Main navigation">
            <a href="#about">About</a>
            <div className="division-menu" onMouseLeave={() => setDivisionsOpen(false)}>
              <button type="button" onClick={() => setDivisionsOpen(!divisionsOpen)} aria-expanded={divisionsOpen}>Divisions <ChevronDown size={14} /></button>
              <div className={`division-popover ${divisionsOpen ? "is-open" : ""}`}>
                {services.map((service) => <a href="#divisions" key={service.title}>{service.title}<ChevronRight size={14} /></a>)}
              </div>
            </div>
            <a href="#stories">Success stories</a>
            <a href="#news">News</a>
            <span className="nav-rule" />
            <a href="#contact">Contact</a>
            <span className="nav-dot" />
          </nav>
          <button className="menu-toggle" type="button" aria-label="Open menu" onClick={() => setMenuOpen(true)}><Menu /></button>
        </div>
      </header>

      <aside className={`mobile-menu ${menuOpen ? "is-open" : ""}`} aria-hidden={!menuOpen}>
        <div className="mobile-menu-head"><Brand /><button type="button" onClick={closeMenu} aria-label="Close menu"><X /></button></div>
        <nav>
          {["About", "Divisions", "Success stories", "News", "Contact"].map((item, index) => (
            <a key={item} href={["#about", "#divisions", "#stories", "#news", "#contact"][index]} onClick={closeMenu}>{item}<ArrowRight size={18} /></a>
          ))}
        </nav>
      </aside>

      <section className="hero-wrap">
        <div className="hero-image" style={{ backgroundImage: `url(${assets.hero})` }}>
          <div className="hero-wash" />
          <div className="hero-copy reveal is-visible">
            <p className="eyebrow">Technology that supports care</p>
            <h1>We drive the future of healthcare with innovative international-quality solutions.</h1>
            <p className="hero-description">We integrate medical and pharmaceutical technology, therapies, and specialized support to raise the regional standard of care.</p>
            <a className="pill-link" href="#contact">Talk with our team <span className="pill-dot" /></a>
          </div>
        </div>
        <div className="proof-window" aria-label="Biofarma highlights">
          <div className="proof-track">
            {loopingProofCards.map((card, index) => (
              <article className={`proof-card proof-${card.kind}`} key={`${card.tag}-${index}`} aria-hidden={index >= proofCards.length}>
                {card.kind === "number" && <div className="proof-figure">{card.figure}<span>{card.suffix}</span></div>}
                {card.kind === "roche" && <div className="roche-logo"><span>Roche</span><b>✓</b></div>}
                {card.kind === "map" && <div className="mini-map"><i /><b>ARG</b><b>CHI</b><b>PER</b></div>}
                {card.kind === "people" && <div className="people-art"><span /><span /><span /></div>}
                {card.kind === "facility" && <div className="facility-art"><span className="facility-sign">biofarma</span><i /><i /><i /></div>}
                {card.kind === "team" && <div className="team-art"><i /><i /><i /><span>+</span></div>}
                <div className="proof-bottom"><p>{card.tag}</p><strong>{card.copy}</strong></div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="about" className="manifesto section-space">
        <div className="manifesto-mark">∿</div>
        <h2 className="reveal">We are an ecosystem of solutions for healthcare-industry challenges. <em>Strategic partners</em> in patient care.</h2>
        <p className="manifesto-copy reveal">We understand the responsibility behind every supply and technology. That is why we unite leading brands with local excellence, from technical and commercial consulting to post-sales support.</p>
      </section>

      <section id="divisions" className="solutions-panel section-space">
        <div className="section-heading reveal"><p className="eyebrow">Our divisions</p><h2>Alongside global leading brands, we provide services and technology from diagnosis through treatment.</h2><p>A structure designed to support the critical needs of the modern medical institution.</p></div>
        <div className="service-grid">
          {services.map((service, index) => (
            <a className="service-card reveal" href="#contact" key={service.title} style={{ transitionDelay: `${index * 80}ms` }}>
              <img src={service.image} alt={service.title} /><div className="service-shade" />
              <div className="service-content"><span>0{index + 1}</span><h3>{service.title}</h3><p>{service.copy}</p><small>Explore <MiniArrow /></small></div>
            </a>
          ))}
        </div>
      </section>

      <section className="partner-section">
        <div className="partner-copy reveal"><p className="eyebrow">Our partner brands</p><h2>Global, strategic partners that trust us.</h2><p>We work to international quality standards throughout the process, helping every implementation deliver dependable results.</p></div>
        <div className="logo-marquee" aria-label="Partner brands"><div className="logo-lane">{["B. BRAUN", "SAMSUNG", "BD", "Roche", "B. BRAUN", "SAMSUNG", "BD", "Roche", "B. BRAUN", "SAMSUNG", "BD", "Roche"].map((brand, i) => <span key={`${brand}-${i}`} className={`brand-logo logo-${brand.replace(/[^A-Z]/g, "").toLowerCase()}`}>{brand}</span>)}</div></div>
      </section>

      <section id="stories" className="case-section section-space">
        <div className="case-copy reveal"><p className="eyebrow">Success stories</p><h2>Thousands of stories behind every installed solution.</h2><p>We work side by side with healthcare professionals to turn technology into real wellbeing and quality of life.</p><a className="text-link" href="#contact">Explore our stories <MiniArrow /></a></div>
        <article className="case-feature reveal"><div className="case-scan" /><div className="case-image"><div className="case-screen"><span>biofarma</span><i /><i /><i /></div></div><div className="case-body"><p>In vitro diagnostics</p><h3>A new diagnostic advance for Mendoza: Biofarma supporting every step</h3><a href="#contact" aria-label="View success story"><MoveUpRight size={20} /></a></div></article>
      </section>

      <section className="coverage-section"><div className="coverage-copy reveal"><p className="eyebrow">Regional healthcare coverage</p><h2>Regional presence</h2><p>With globally leading brands, we offer 360° coverage across the healthcare sector.</p><a className="pill-link dark-pill" href="#contact">Discover our reach <span className="pill-dot" /></a></div><div className="map-visual reveal" aria-label="Illustrated map of regional presence"><div className="continent south"><span className="map-pin pin-arg">ARG</span><span className="map-pin pin-chi">CHI</span><span className="map-pin pin-per">PER</span></div><div className="map-orbit orbit-one" /><div className="map-orbit orbit-two" /></div></section>

      <section className="faq-section section-space"><div className="faq-title reveal"><p className="eyebrow">Frequently asked questions</p><h2>Information about Biofarma.</h2><p>Answers to initial questions about our experience, regional coverage, and way of working.</p></div><div className="faq-layout"><Accordion type="single" collapsible className="faq-list reveal">{faqs.map(([question, answer], index) => <AccordionItem value={`item-${index}`} key={question}><AccordionTrigger>{question}</AccordionTrigger><AccordionContent>{answer}</AccordionContent></AccordionItem>)}</Accordion><aside className="faq-aside reveal"><span className="aside-star">✦</span><strong>Have a project in mind?</strong><p>Our team can help identify the most appropriate solution.</p><a href="#contact">Contact us <ChevronRight size={16} /></a></aside></div></section>

      <section id="contact" className="contact-banner section-space"><div className="contact-photo" /><div className="contact-content reveal"><p className="eyebrow">A team that stays close</p><h2>We support healthcare institutions with reliable, high-quality medical solutions.</h2><a className="pill-link dark-pill" href="mailto:rrhh@biofarma.com.ar">Let’s talk <span className="pill-dot" /></a></div></section>

      <section className="voices-section section-space"><div className="voices-top reveal"><p className="eyebrow">The voices that move us</p><h2>Knowledge is also meant to be shared.</h2><p>People who make Biofarma a regional network of experience, commitment, and healthcare.</p></div><div className="voices-grid"><article className="voice-card voice-main reveal"><div className="voice-portrait portrait-a" /><div><p>“Staying close to each institution is part of the way we understand healthcare.”</p><strong>Mariana Kamariski</strong><small>Pediatric nephrology</small></div></article><article className="voice-card reveal"><div className="voice-portrait portrait-b" /><p>We connect technology and support so every implementation can fulfil its purpose.</p><span>Biofarma team</span></article><article className="voice-card reveal"><div className="voice-portrait portrait-c" /><p>Quality is built in every conversation, every detail, and every delivery.</p><span>Biofarma team</span></article></div></section>

      <section id="news" className="news-section section-space"><div className="news-heading reveal"><div><p className="eyebrow">News</p><h2>Biofarma and the industry</h2></div><a className="text-link" href="#contact">View articles <MiniArrow /></a></div><div className="news-grid"><article className="news-card reveal"><div className="news-thumb thumb-samsung"><span>SAMSUNG</span></div><p>Diagnostic imaging</p><h3>Samsung arrives at Biofarma for diagnostic imaging</h3><a href="#contact" aria-label="Read Samsung article"><Plus size={17} /></a></article><article className="news-card reveal"><div className="news-thumb thumb-family"><span>Biofarma</span></div><p>Community</p><h3>Celebrating Family Day</h3><a href="#contact" aria-label="Read Family Day article"><Plus size={17} /></a></article><article className="news-card reveal"><div className="news-thumb thumb-punto"><span>Punto BIO</span></div><p>Stories</p><h3>Punto BIO: the voices that shape our history</h3><a href="#contact" aria-label="Read Punto BIO article"><Plus size={17} /></a></article></div></section>

      <footer className="site-footer">
        <div className="footer-shell">
          <section className="footer-branding"><Brand footer /><strong>Specialists in providing<br />medical solutions.</strong><p>We are leaders in supplying clinics, hospitals, and laboratories. Specialists in providing medical solutions.</p><div className="country-pills"><span><i className="flag-chile" /> CHI</span><span><i className="flag-peru" /> PER</span></div></section>
          <nav className="footer-column footer-map"><a href="#about">About</a><a href="#stories">Success stories</a><a href="#news">News</a><a href="#contact">Contact</a></nav>
          <nav className="footer-column footer-divisions"><p>Divisions</p><a href="#divisions">Clinical laboratories</a><a href="#divisions">Medical devices</a><a href="#divisions">Pharma</a></nav>
          <div className="footer-certifications"><span>IQNET</span><span>IQC</span><span>ISO<br />9001</span></div>
          <nav className="footer-column footer-legal"><a href="#top">Terms of use</a><a href="#top">Privacy policy</a></nav>
          <div className="footer-socials"><p>Follow us</p><div><a href="#top" aria-label="Facebook"><Facebook size={20} fill="currentColor" /></a><a href="#top" aria-label="Instagram"><Instagram size={21} /></a><a href="#top" aria-label="LinkedIn"><Linkedin size={20} fill="currentColor" /></a></div></div>
          <p className="footer-credit">2026 — Biofarma. All rights reserved. Design by Disruptive®</p>
        </div>
        <a href="#divisions" className="division-teaser"><span><small>Discover our</small>Divisions</span><b><ArrowRight size={20} /></b></a>
      </footer>
    </main>
  );
}
