# Biofarma recreation — visual reference specification

## Chosen approach: source-faithful healthcare editorial

This implementation uses the supplied Biofarma homepage screenshot and the inspected live page as the **ground-truth reference**. Fidelity to its visual behavior takes priority over introducing a new visual direction. The intended feeling is clean, technically credible, and quietly optimistic: soft pale-lavender fields, deep teal copy, a restrained fuchsia accent, generous white space, round-cornered image surfaces, and a layered horizontal proof carousel.

### Design movement

Contemporary Latin American healthcare editorial. The composition is deliberately light and precise, combining immersive clinical imagery with a friendly, rounded interface language.

### Core principles

1. **Reference-first geometry:** The rounded white navigation shell, oversized image-led hero, overlapping proof cards, vertical spacing, and calm asymmetric section compositions must preserve the source’s hierarchy.
2. **Clinical warmth:** Use a blue-lavender canvas, white cards, deep green-black text, and a measured coral-pink accent to balance technology and human care.
3. **Editorial restraint:** Copy is concise and left-led, rather than being centrally stacked. Image and text blocks retain substantial breathing room.
4. **Purposeful movement:** Entrances, card hover shifts, marquees, accordions, and image zooms should be smooth, light, and non-intrusive.

### Color philosophy

The nearly white lavender canvas lets rich medical imagery remain the visual focus. Deep teal supplies reliable contrast and scientific confidence. Biofarma pink is used as a sparing signal for labels, anchor dots, location markers, and directional details rather than as a decorative wash.

### Layout paradigm

Layered story progression rather than a conventional centered-card grid. The hero establishes a large editorial frame; the proof cards deliberately escape that frame at its lower edge. Subsequent sections alternate an open text-led field, a wide pastel panel, scrolling partner names, editorial case-study cards, a regional map, and compact stacks of information.

### Signature elements

- Floating white proof cards with large numerals or real-world healthcare images.
- A small fuchsia dot that completes CTAs, navigation, labels, and map markers.
- Pale blue-to-blush surfaces that quietly separate major information chapters.

### Interaction philosophy

Navigation and cards should react with calm physicality. Buttons compress slightly on press, cards lift a small amount on hover, navigation reveals a gentle dropdown, and accordion rows expand with preserved reading rhythm. Touch interactions keep controls obvious and never depend on hover alone.

### Animation

Use transform and opacity motion only. Section-level entrance reveals should travel 18–28px upward with 420–650ms `cubic-bezier(0.23, 1, 0.32, 1)` timing and modest 50–80ms staggering. The partner row moves in a low-speed continuous loop. Image cards may scale to 1.03 on hover with a 400ms ease. Disable non-essential motion under `prefers-reduced-motion`.

### Typography system

Use a light-to-regular geometric sans for headings and a readable companion sans for body copy. The hero heading must remain thin, wide, and left-aligned, with its line breaks retained as closely as the responsive layout allows. Overlines and proof-card labels use smaller all-caps fuchsia text with moderate tracking.

### Brand essence

**A regional healthcare technology partner for institutions that need clinically reliable solutions and real implementation support.**

Personality: **calm, expert, human.**

### Brand voice

Headlines are direct, future-facing, and rooted in outcomes. CTAs are conversational but concrete, never generic.

Examples: “Impulsamos el futuro de la salud.” and “Conocé las soluciones que acompañan cada implementación.”

### Wordmark and logo

Use the supplied/inspected Biofarma mark as a visible anchor within the white navigation bar and footer. The mark should feel generous in scale rather than being reduced to a tiny utility icon.

### Signature brand color

**Biofarma pink — `#ec3d78`**. This is reserved for the dot motif, small labels, active directions, and light moments of emphasis.
***
