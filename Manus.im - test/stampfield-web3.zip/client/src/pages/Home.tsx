/**
 * STAMPFIELD STYLE REMINDER — Web-native Ecliptic Field: one continuous graphite world,
 * orbit-based navigation, living signal windows, rich hover states, and sparse display copy.
 */
import { useEffect, useRef, useState, type FormEvent, type PointerEvent as ReactPointerEvent } from "react";
import Lenis from "lenis";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { ArrowDownRight, ArrowUpRight, ChevronRight, Menu, Plus, Radio, X } from "lucide-react";

const ASSETS = {
  mark: "/manus-storage/stampfield-ecliptic-mark_67d93dc8.png",
  hero: "/manus-storage/stampfield-ecliptic-hero_6231c5b7.png",
  orbit: "/manus-storage/stampfield-ecliptic-orbit_db5fbb00.png",
  portal: "/manus-storage/stampfield-ecliptic-portal_84fabf93.png",
  sculpture: "/manus-storage/stampfield-ecliptic-sculpture_956c5f4b.png",
};

const signals = [
  { id: "01", title: "Afterimage", tag: "OBJECT STUDY", image: ASSETS.orbit, copy: "A small archive of things that appeared once, then kept pulling people back.", coordinate: "03.14 / 87.02", hue: "iris" },
  { id: "02", title: "Soft power", tag: "SHARED SPACE", image: ASSETS.sculpture, copy: "A neighborhood for references that change shape as more people leave a signal.", coordinate: "04.28 / 12.91", hue: "pearl" },
  { id: "03", title: "No fixed point", tag: "FIELD NOTE", image: ASSETS.portal, copy: "A passage for ideas that do not need to become content to become valuable.", coordinate: "11.02 / 06.45", hue: "shadow" },
];

function Glyph() {
  return <span className="eclipse-glyph" aria-hidden="true"><i /><b /></span>;
}

function HoverField({ signal, index, onOpen }: { signal: (typeof signals)[number]; index: number; onOpen: () => void }) {
  const reducedMotion = useReducedMotion();
  return (
    <motion.article
      className={`hover-field hover-field--${signal.hue} hover-field--${index + 1}`}
      initial={reducedMotion ? false : { opacity: 0, y: 32 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.25 }}
      transition={{ duration: 0.7, delay: index * 0.08, ease: "circOut" }}
      whileHover={reducedMotion ? undefined : { y: -9, rotate: index === 1 ? -1.1 : 1.1 }}
      onClick={onOpen}
      tabIndex={0}
      role="button"
      onKeyDown={(event) => { if (event.key === "Enter") onOpen(); }}
    >
      <div className="hover-field__label"><span>{signal.id}</span><span>{signal.tag}</span><ArrowUpRight size={14} /></div>
      <div className="hover-field__image"><img src={signal.image} alt={`${signal.title} signal visual`} /></div>
      <div className="hover-field__footer"><h3>{signal.title}</h3><span>{signal.coordinate}</span></div>
      <div className="hover-field__veil"><p>{signal.copy}</p><span>OPEN FIELD <ArrowDownRight size={14} /></span></div>
    </motion.article>
  );
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [selectedSignal, setSelectedSignal] = useState(0);
  const [noteOpen, setNoteOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [pointer, setPointer] = useState({ x: 0, y: 0 });
  const heroRef = useRef<HTMLElement>(null);
  const lenisRef = useRef<Lenis | null>(null);
  const reducedMotion = useReducedMotion();
  const active = signals[selectedSignal];

  useEffect(() => {
    if (reducedMotion) return;
    const lenis = new Lenis({ lerp: 0.075, wheelMultiplier: 0.86, syncTouch: true, touchMultiplier: 1.25 });
    lenisRef.current = lenis;
    let request = 0;
    const raf = (time: number) => { lenis.raf(time); request = requestAnimationFrame(raf); };
    request = requestAnimationFrame(raf);
    return () => { cancelAnimationFrame(request); lenis.destroy(); lenisRef.current = null; };
  }, [reducedMotion]);

  const goTo = (id: string) => {
    setMenuOpen(false);
    const node = document.getElementById(id);
    if (!node) return;
    if (lenisRef.current) lenisRef.current.scrollTo(node, { offset: -74 });
    else node.scrollIntoView({ behavior: "smooth" });
  };

  const onPointerMove = (event: ReactPointerEvent<HTMLElement>) => {
    if (reducedMotion || !heroRef.current) return;
    const rect = heroRef.current.getBoundingClientRect();
    setPointer({ x: (event.clientX - rect.left - rect.width / 2) / rect.width, y: (event.clientY - rect.top - rect.height / 2) / rect.height });
  };

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (email.trim()) setSubmitted(true);
  };

  return (
    <div className="field-site">
      <div className="world-atmosphere" aria-hidden="true"><span className="world-atmosphere__orb world-atmosphere__orb--one" /><span className="world-atmosphere__orb world-atmosphere__orb--two" /><span className="world-atmosphere__path" /></div>
      <header className="field-header">
        <button className="field-brand" onClick={() => goTo("home")} aria-label="Stampfield home"><Glyph /><span>STAM•FIELD</span></button>
        <nav className="field-nav" aria-label="Primary navigation"><button onClick={() => goTo("signals")}>SIGNALS</button><button onClick={() => goTo("note")}>FIELD NOTE</button><button onClick={() => goTo("access")}>ACCESS</button></nav>
        <button className="field-status" onClick={() => goTo("signals")}><Radio size={12} /><span>LIVE FIELD</span><b>03</b></button>
        <button className="field-menu" onClick={() => setMenuOpen(!menuOpen)} aria-expanded={menuOpen} aria-label="Toggle menu">{menuOpen ? <X size={20} /> : <Menu size={20} />}</button>
        <AnimatePresence>{menuOpen && <motion.nav className="field-mobile-nav" initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }} transition={{ duration: 0.2, ease: "circOut" }}><button onClick={() => goTo("signals")}>SIGNALS <ChevronRight size={18} /></button><button onClick={() => goTo("note")}>FIELD NOTE <ChevronRight size={18} /></button><button onClick={() => goTo("access")}>ACCESS <ChevronRight size={18} /></button></motion.nav>}</AnimatePresence>
      </header>

      <main id="home">
        <section className="field-hero" ref={heroRef} onPointerMove={onPointerMove} aria-labelledby="field-title">
          <div className="field-hero__grid" />
          <div className="field-hero__bar"><span>FIELD / 001</span><span>OBSERVATION WINDOW OPEN</span><span>38.903 N / 77.050 W</span></div>
          <div className="field-hero__copy">
            <motion.p className="field-hero__pre" initial={reducedMotion ? false : { opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, ease: "circOut" }}><i /> A QUIETER PLACE FOR CULTURE</motion.p>
            <motion.h1 id="field-title" initial={reducedMotion ? false : { opacity: 0, y: 38 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9, delay: 0.08, ease: "circOut" }}>FOLLOW WHAT<br /><em>STAYS</em> WITH YOU.</motion.h1>
            <motion.div className="field-hero__actions" initial={reducedMotion ? false : { opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.65, delay: 0.28, ease: "circOut" }}><button onClick={() => goTo("signals")}>ENTER THE FIELD <ArrowDownRight size={17} /></button><p>Small cultural signals, arranged around the people who keep them alive.</p></motion.div>
          </div>
          <motion.div className="field-hero__object" animate={reducedMotion ? {} : { x: pointer.x * 22, y: pointer.y * 18, rotateY: pointer.x * 4, rotateX: pointer.y * -3 }} transition={{ type: "spring", stiffness: 95, damping: 20 }}>
            <div className="field-hero__orbit field-hero__orbit--one" /><div className="field-hero__orbit field-hero__orbit--two" />
            <motion.img src={ASSETS.hero} alt="Faceted Stampfield ecliptic object" animate={reducedMotion ? {} : { y: [0, -8, 0] }} transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }} />
            <span className="field-hero__object-caption">ECLIPTIC OBJECT / 01<br />MATERIAL: LIGHT + MEMORY</span><b className="field-hero__object-dot" />
          </motion.div>
          <div className="field-hero__aside"><span>SCROLL TO<br />LOCATE A SIGNAL</span><i /></div>
        </section>

        <section className="signal-region" id="signals" aria-labelledby="signals-title">
          <div className="region-head"><div><span className="index-no">01</span><p>LIVE SIGNALS</p></div><p>Things moving through the field<br />right now.</p></div>
          <div className="signal-intro"><motion.h2 id="signals-title" initial={reducedMotion ? false : { opacity: 0, y: 28 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.5 }} transition={{ duration: 0.72, ease: "circOut" }}>A FEW THINGS<br />ARE <em>PULLING</em><br />US CLOSER.</motion.h2><div className="signal-intro__status"><span><i /> THREE ACTIVE PULLS</span><p>Select a field window to see where it leads.</p></div></div>
          <div className="signal-layout"><div className="signal-cards">{signals.map((signal, index) => <HoverField signal={signal} index={index} onOpen={() => setSelectedSignal(index)} key={signal.id} />)}</div>
            <motion.aside className="signal-monitor" key={active.id} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.4, ease: "circOut" }}><div className="signal-monitor__top"><span>SELECTED FREQUENCY</span><b>{active.id}/03</b></div><div className="signal-monitor__line"><i /></div><p className="signal-monitor__tag">{active.tag}</p><h3>{active.title}</h3><p className="signal-monitor__copy">{active.copy}</p><div className="signal-monitor__meta"><span>COORDINATE</span><b>{active.coordinate}</b></div><button onClick={() => goTo("note")}>FOLLOW THIS PULL <ArrowDownRight size={15} /></button></motion.aside>
          </div>
        </section>

        <section className="note-region" id="note" aria-labelledby="note-title">
          <div className="note-region__scene" style={{ backgroundImage: `url(${ASSETS.portal})` }} /><div className="note-region__wash" />
          <div className="note-region__content"><div className="region-head region-head--light"><div><span className="index-no">02</span><p>FIELD NOTE / 009</p></div><p>AN OPEN LETTER FROM<br />THE EDGE OF THE ORBIT</p></div>
            <motion.h2 id="note-title" initial={reducedMotion ? false : { opacity: 0, y: 28 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.45 }} transition={{ duration: 0.72, ease: "circOut" }}>THE INTERNET<br />DOESN’T NEED<br />TO BE <em>LOUD.</em></motion.h2>
            <div className="note-region__bottom"><p>It can have rooms. It can have people who return. It can make space for a question that does not turn into a race.</p><button className={`note-expand ${noteOpen ? "note-expand--open" : ""}`} onClick={() => setNoteOpen(!noteOpen)}><span>{noteOpen ? "CLOSE FIELD NOTE" : "OPEN FIELD NOTE"}</span><i><Plus size={17} /></i></button></div>
            <AnimatePresence>{noteOpen && <motion.div className="note-drawer" initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 14 }} transition={{ duration: 0.35, ease: "circOut" }}><span>EXCERPT / 09</span><p>“The signals worth following rarely arrive with a countdown. They gather slowly, become familiar, and make the rest of the web feel a little more possible.”</p></motion.div>}</AnimatePresence>
          </div>
        </section>

        <section className="field-map" aria-labelledby="map-title"><div className="field-map__scribble" /><div className="field-map__header"><span className="index-no">03</span><p id="map-title">THE FIELD DOES THREE THINGS</p><span>NO ALGORITHM REQUIRED</span></div><div className="map-points"><motion.article initial={reducedMotion ? false : { opacity: 0, y: 22 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.55, ease: "circOut" }}><span>01</span><h3>KEEP A TRACE.</h3><p>Hold onto the pieces of the internet you know you will want to find again.</p></motion.article><motion.article initial={reducedMotion ? false : { opacity: 0, y: 22 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.55, delay: 0.08, ease: "circOut" }}><span>02</span><h3>LEAVE A SIGNAL.</h3><p>Let someone know why it stayed with you. Small attention changes the route.</p></motion.article><motion.article initial={reducedMotion ? false : { opacity: 0, y: 22 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.55, delay: 0.16, ease: "circOut" }}><span>03</span><h3>FIND YOUR PEOPLE.</h3><p>Make the room a little more yours, then see who comes closer.</p></motion.article></div></section>

        <section className="access-region" id="access" aria-labelledby="access-title"><div className="access-region__orb" /><motion.div className="access-card" initial={reducedMotion ? false : { opacity: 0, y: 28 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.4 }} transition={{ duration: 0.7, ease: "circOut" }}><div className="access-card__top"><div><Glyph /><span>STAM•FIELD</span></div><span>ACCESS LOG / 0009</span></div><h2 id="access-title">LEAVE YOUR<br />COORDINATE.</h2><p>One quiet note when a new field opens.</p><form onSubmit={submit}><div className="access-form"><input value={email} onChange={(event) => { setEmail(event.target.value); setSubmitted(false); }} type="email" placeholder="email address" aria-label="Email address" required /><button type="submit"><span>HOLD MY PLACE</span><ArrowUpRight size={16} /></button></div><AnimatePresence>{submitted && <motion.p className="access-success" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>Your coordinate has been saved.</motion.p>}</AnimatePresence></form></motion.div></section>
      </main>

      <footer className="field-footer"><div className="footer-brand"><Glyph /><span>STAM•FIELD</span></div><p>KEEPING CULTURE<br />IN ORBIT.</p><div><button>INSTAGRAM</button><button>FARCASTER</button><button>CONTACT</button></div><small>© 2025 STAM•FIELD / NO SIGNAL LOST</small></footer>
    </div>
  );
}
