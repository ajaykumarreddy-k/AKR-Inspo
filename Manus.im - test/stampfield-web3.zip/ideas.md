# Stampfield — Premium Redesign Direction

## Three visual directions

### The Ecliptic House

**Very Brief Intro:** A nocturnal, cinematic digital house built around a single magnetic celestial object. It uses ritual, silence, and controlled flashes of iridescent light to make browsing feel like entering an exhibition after dark.

**Probability:** 0.04

### Liquid Index

**Very Brief Intro:** A pale mineral world where glass, chrome, and fluid typography become a living catalogue of culture. It feels like an art-book interface under water: precise, glossy, and unexpectedly soft.

**Probability:** 0.07

### Signal Garden

**Very Brief Intro:** A warm, high-craft landscape of black lacquer, engineered flora, and intimate member trails. It turns network activity into an atmospheric garden walk rather than a digital product dashboard.

**Probability:** 0.03

## Chosen approach — The Ecliptic House

**Design Movement:** Digital minimalism meets cinematic art direction, drawing from contemporary fashion-film title sequences, astronomical observatories, and Japanese luxury packaging.

**Core Principles:** The experience uses a restrained black field as a stage, not as a technical interface. A single luminous object must carry every major scene, with negative space treated as an intentional luxury. Typography is architectural, oversized, and editorially paced. Interactions should feel like controlled magnetic fields—not little UI tricks.

**Color Philosophy:** The base is **Graphite Night** (`#070706`) and almost-black graphite rather than pure black. Lunar ivory (`#F4F0E6`) is reserved for type and perceptual warmth. **Ecliptic Iris** (`#9C8CFF`) is the singular ownable electric note, moving between lavender, cobalt, and pearl through subtle light effects. A sparing ember orange will appear only in active states and metadata pulses.

**Layout Paradigm:** The page is a gallery sequence of full-bleed cinematic scenes divided by pauses. The hero is an off-center typographic wall with a large floating orbital artifact. Below it, horizontal editorial panels cut across the viewport, then resolve into an immersive black ledger and a final invitation chamber. Central card grids are avoided in favor of asymmetry, overlap, and full-width transitions.

**Signature Elements:** The signature object is a glossy faceted celestial monolith rendered in purple-blue pearl. Each scene uses fine orbital paths, an “ecliptic” dot, and a simple indexed coordinate system. Text sits against carefully protected calm regions, while a soft film-grain veil unifies the page.

**Interaction Philosophy:** Pointer movement should create a restrained parallax response in the hero object and star field. On scroll, content slides into alignment as if entering an orbit. Buttons behave like physical controls—tight, confident, and quiet—with only micro-scale press feedback. The goal is lingering attention rather than animation density.

**Animation:** Lenis smooth scroll remains the foundation. Framer Motion entrances use long 700–1100ms cinematic ease-outs, translating 28–54px with generous breathing room. The hero monolith drifts in a near-imperceptible floating loop, while its highlight responds to the cursor. Lines should draw subtly and text masks should reveal from bottom to top. Motion respects reduced-motion preferences and avoids looping motion outside the hero.

**Typography System:** `DM Sans` for body and controls, `Bodoni Moda` for display accents, and `IBM Plex Mono` for coordinate metadata. Main headings use a wide, uncluttered sans serif at large sizes, with a single italic high-contrast serif word for tension. The text system should feel like a gallery invitation, never like a crypto exchange.

**Brand Essence:** **Stampfield is an atmospheric gathering place for the culture being stored on-chain.** Personality: **cinematic, discerning, magnetic**.

**Brand Voice:** Calm, precise, and invitational. Headlines frame a feeling rather than sell a feature. CTAs are spatial and directional rather than transactional.

> “A place to find what the feed forgot.”
>
> “Step inside the signal.”

**Wordmark & Logo:** A refined uppercase `STAM•FIELD` wordmark with an elliptical eclipse glyph: two offset discs where a small iris sliver appears at the edge. The mark should work alone as a lunar coordinate, never as a noisy web3 icon.

**Signature Brand Color:** **Ecliptic Iris — `#9C8CFF`**.

## Style Decisions

This redesign intentionally discards the prior pale-blue, stamp-print, playful ephemera treatment. The work should now feel materially more cinematic, quieter, and more premium, with a completely different page architecture and visual cadence.

The ecliptic iris is exclusively an emitted-light signal, orbital pulse, selected serif emphasis, or controlled chamber glow—not a broad poster background. Secondary objects are visually reduced into the same black-chrome, pearl-lavender material family as the central monolith. In core identity moments, the two-disc eclipse glyph always pairs with the spaced uppercase `STAM•FIELD` wordmark.

## Web-native continuity pass

The site must not read as a stack of campaign slides. The new composition is a single **living field**: a persistent dark canvas with an animated orbital thread and a compact global navigation layer that remains available as the visitor moves. Information should arrive as floating field windows, small live index cards, and overlapping modules within one consistent coordinate grid, with only the opening scene using a hero-scale statement.

The interaction model should reward a second visit. An ambient cursor aura, a live “signal” readout, hover-responsive field windows, and an expandable field note make the site feel operational rather than merely presentational. The page becomes a destination that can be browsed in different orders: sections are waypoints on a single map, not chapters in a deck. Typography becomes more varied in scale and contextual; large display copy is used sparingly and wrapped in smaller utility content.
